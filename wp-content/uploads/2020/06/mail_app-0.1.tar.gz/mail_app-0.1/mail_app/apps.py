from django.apps import AppConfig


class MailAppConfig(AppConfig):
    name = 'mail_app'
